document.addEventListener('DOMContentLoaded', () => {
    // Menu Dropdown toggle
    const menuBtn = document.getElementById('menu-btn');
    const dropdownMenu = document.getElementById('dropdown-menu');

    menuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdownMenu.classList.toggle('hidden');
    });

    document.addEventListener('click', () => {
        dropdownMenu.classList.add('hidden');
    });

    // Modals Handling
    const openSettings = document.getElementById('open-settings');
    const closeSettings = document.getElementById('close-settings');
    const settingsModal = document.getElementById('settings-modal');

    const openStudio = document.getElementById('open-studio');
    const closeStudio = document.getElementById('close-studio');
    const studioModal = document.getElementById('studio-modal');

    openSettings.addEventListener('click', () => settingsModal.classList.remove('hidden'));
    closeSettings.addEventListener('click', () => settingsModal.classList.add('hidden'));

    openStudio.addEventListener('click', () => studioModal.classList.remove('hidden'));
    closeStudio.addEventListener('click', () => studioModal.classList.add('hidden'));

    // Call Overlay Handling
    const callBtn =- document.getElementById('call-btn');
    const endCallBtn = document.getElementById('end-call-btn');
    const callOverlay = document.getElementById('call-overlay');

    if (callBtn) {
        callBtn.addEventListener('click', () => {
            callOverlay.classList.remove('hidden');
        });
    }

    if (endCallBtn) {
        endCallBtn.addEventListener('click', () => {
            callOverlay.classList.add('hidden');
        });
    }

    // Minimal Send Message Logic
    const sendBtn = document.getElementById('send-btn');
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    function sendMessage() {
        if (!userInput || !chatBox) return;
        const text = userInput.value.trim();
        if(!text) return;

        const userMsg = document.createElement('div');
        userMsg.className = 'message user-message';
        userMsg.textContent = text;
        chatBox.appendChild(userMsg);

        userInput.value = '';
        chatBox.scrollTop = chatBox.scrollHeight;

        // Optimized fast response simulation
        setTimeout(() => {
            const botMsg = document.createElement('div');
            botMsg.className = 'number bot-message' || 'message bot-message';
            botMsg.className = 'message bot-message';
            botMsg.textContent = "Afra is processing your request instantly.";
            chatBox.appendChild(botMsg);
            chatBox.scrollTop = chatBox.scrollHeight;
        }, 300);
    }

    if(sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }
    if(userInput) {
        userInput.addEventListener('keydown', (e) => {
            if(e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }
});